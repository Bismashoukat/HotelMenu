#Define the menu of restaurant
# # menu = {
#     'Pizza':40,
#     'Pasta':50,
#     'Burger':60,
#     'Saled':70,
#     'Coffee':80,
# }


# #Greet
# print("Welcom to Python Restaurant")
# print("Pizza: Rs40\nPasta: Rs50\nBurger: Rs60\nSaled: Rs70\nCoffee: Rs80 ")

# order_total = 0
# #80 + 70 = 150

# item_1 = input("Enter the name of item you want to order = ")
# if item_1 in menu:
#     order_total += menu[item_1] #0 + 50
#     print(f"Your item {item_1} has been added to your order")

# else:
#     print(f"Ordered item {item_1} is not avaialable yet!")

#     another_order = input("Do you want to add another item? (yes/No) ")
#     if another_order == "Yes":
#         item_2 = input("Enter the name of Second item = ")
#         if item_2 in menu:
#             order_total += menu[item_2]
#             print(f"Item {item_2} has been added to your order")
#         else:
#             print(f"Ordered item {item_2} is not avaialable!")
# print(f"The total amount of items to pay is  Rs{order_total}")
# Restaurant Menu
menu = {
    'pizza': 40,
    'pasta': 50,
    'burger': 60,
    'salad': 70,
    'coffee': 80,
}

print("Welcome to Python Restaurant")
print("Here is our menu:")
for item, price in menu.items():
    print(f"{item.title()}: Rs{price}")

order_total = 0
ordered_items = []

while True:
    item = input("\nEnter the name of item you want to order: ").lower()
    if item in menu:
        order_total += menu[item]
        ordered_items.append(item.title())
        print(f"Item {item.title()} has been added to your order.")
    else:
        print(f"Sorry! {item.title()} is not available.")

    another = input("Do you want to add another item? (yes/no): ").lower()
    if another != "yes":
        break

# Final Bill
print("\nYour Order Summary:")
for item in ordered_items:
    print(f"- {item}: Rs{menu[item.lower()]}")
print(f"Total amount to pay: Rs{order_total}")